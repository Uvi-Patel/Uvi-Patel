//
//  GoogleIntestrialAds.swift
//  Random Live Video Call
//
//  Created by MAC on 22/04/21.
//

import Foundation
import UIKit
import GoogleMobileAds

// MARK:- ------------------Google Intesrtrial Ads-----------------
class IntestrialAdsGoogle: NSObject {
    static let sharedInstance = IntestrialAdsGoogle()
    var interstitial : GADInterstitialAd!
    var currentFrequencyCount: Int = 0
    
    var vc: UIViewController!
    
    func createAndLoadIntestrial(){
        let request = GADRequest()
        GADInterstitialAd.load(withAdUnitID: interstitialAdsUnitID, request: request) { (ad, error) in
            if let error = error{
//                print("Failed to load interstitial ad with error: \(error.localizedDescription)")
                return
            }
            self.interstitial = ad
            self.interstitial?.fullScreenContentDelegate = self
        }
    }
    
    func showFromViewController(vc : UIViewController){
        self.vc = vc
        if interstitial != nil{
            self.currentFrequencyCount = 0
            interstitial.present(fromRootViewController: vc)
        }else{
            self.createAndLoadIntestrial()
        }
    }
    
    func showFromViewControllerPush(vc : UIViewController){
        self.vc = vc
        self.currentFrequencyCount = currentFrequencyCount+1
        if currentFrequencyCount >= interstitialFrequencyCount{
            if interstitial != nil{
                self.currentFrequencyCount = 0
                interstitial.present(fromRootViewController: vc)
            }else{
                self.createAndLoadIntestrial()
            }
        }else{
            if interstitial == nil{
                self.createAndLoadIntestrial()
            }
        }
    }
}

// MARK:- ------------------GADFullScreenContentDelegate-----------------
extension IntestrialAdsGoogle: GADFullScreenContentDelegate{
    /// Tells the delegate that the ad failed to present full screen content.
      func ad(_ ad: GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
//        print("Ad did fail to present full screen content.")
      }

      /// Tells the delegate that the ad presented full screen content.
      func adDidPresentFullScreenContent(_ ad: GADFullScreenPresentingAd) {
//        print("Ad did present full screen content.")
      }

      /// Tells the delegate that the ad dismissed full screen content.
      func adDidDismissFullScreenContent(_ ad: GADFullScreenPresentingAd) {
//        print("Ad did dismiss full screen content.")
        self.createAndLoadIntestrial()
      }
}
