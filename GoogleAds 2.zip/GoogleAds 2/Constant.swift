//
//  Constant.swift
//  Animal Face Maker App
//
//  Created by MAC on 06/08/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import Foundation
import UIKit
import GoogleMobileAds


var bannerAdsUnitID: String = "ca-app-pub-3940256099942544/6300978111"
var interstitialAdsUnitID: String = "ca-app-pub-3940256099942544/1033173712"
var nativeAdsUnitID: String = "ca-app-pub-3940256099942544/2247696110"
var appOpenAdsUnitId: String = "ca-app-pub-6062872451360941/9524310964"
let testDeviceId: [String] = ["409658f9d49669aaa6e9bf87d46c8a11","f6c2ffcc488463447cd2c50a82db6d4c","0aa031f333727f5e595219f7e07e5839", "\(kGADSimulatorID)"]
var interstitialFrequencyCount: Int = 4
