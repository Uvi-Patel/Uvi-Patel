//
//  File.swift
//  Random Live Video Call
//
//  Created by MAC on 16/04/21.
//

import Foundation
import GoogleMobileAds
import UIKit

// MARK:- ------------------Google Native Ads-----------------
class NativeAdsGoogle: NSObject{
    static let sharedInstance = NativeAdsGoogle()
    var adLoader: GADAdLoader!
    var nativeAdView: GADNativeAdView!
    var hideView: UIView!
    var height: NSLayoutConstraint!
    
    var vc: UIViewController!
    
    func createAndLoadNative() -> GADAdLoader{
        let options = GADMultipleAdsAdLoaderOptions()
        options.numberOfAds = 1

        // Prepare the ad loader and start loading ads.
         let adLoader = GADAdLoader(adUnitID: nativeAdsUnitID,
                               rootViewController: vc,
                               adTypes: [.native],
                               options: [options])
        adLoader.delegate = self
        adLoader.load(GADRequest())
        return adLoader
    }
    
    func showFromViewController(vc:UIViewController, view:UIView, height:NSLayoutConstraint){
        self.height = height
        guard let nibObjects = Bundle.main.loadNibNamed("UnifiedNativeAdView", owner: nil, options: nil),
        let adView = nibObjects.first as? GADNativeAdView
            else {
                assert(false, "Could not load nib file for adView")
                return
        }
        hideView = view
        hideView.isHidden = true
        nativeAdView = adView
        view.addSubview(nativeAdView)
        nativeAdView.translatesAutoresizingMaskIntoConstraints = false

        let topConstraint = NSLayoutConstraint(item: nativeAdView as Any, attribute: .top, relatedBy: .equal, toItem: view, attribute: .top, multiplier: 1, constant: -20)
        let widthConstraint = NSLayoutConstraint(item: nativeAdView as Any, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: UIScreen.main.bounds.size.width)
        let heightConstraint = NSLayoutConstraint(item: nativeAdView as Any, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 200)
        NSLayoutConstraint.activate([topConstraint, widthConstraint, heightConstraint])
        
        adLoader = createAndLoadNative()
    }
    
    
    func imageOfStars(from starRating: NSDecimalNumber?) -> UIImage? {
        guard let rating = starRating?.doubleValue else {
            return nil
        }
        if rating >= 5 {
            return UIImage(named: "stars_5")
        } else if rating >= 4.5 {
            return UIImage(named: "stars_4_5")
        } else if rating >= 4 {
            return UIImage(named: "stars_4")
        } else if rating >= 3.5 {
            return UIImage(named: "stars_3_5")
        } else {
            return nil
        }
    }
}

// MARK:- -----------------GADNativeAdLoaderDelegate Methodes-----------------
extension NativeAdsGoogle: GADNativeAdLoaderDelegate{
    func adLoader(_ adLoader: GADAdLoader, didReceive nativeAd: GADNativeAd) {
        nativeAd.delegate = self
        
            (nativeAdView.headlineView as? UILabel)?.text = nativeAd.headline
            nativeAdView.mediaView?.mediaContent = nativeAd.mediaContent
                    
            (nativeAdView.bodyView as? UILabel)?.text = nativeAd.body
            nativeAdView.bodyView?.isHidden = nativeAd.body == nil

            (nativeAdView.callToActionView as? UIButton)?.setTitle(nativeAd.callToAction, for: .normal)
            nativeAdView.callToActionView?.isHidden = nativeAd.callToAction == nil
                    
            (nativeAdView.iconView as? UIImageView)?.image = nativeAd.icon?.image
//            nativeAdView.iconView?.isHidden = nativeAd.icon == nil
//            nativeAdView.iconView?.isHidden = true
                    
            (nativeAdView.starRatingView as? UIImageView)?.image = imageOfStars(from: nativeAd.starRating)
            nativeAdView.starRatingView?.isHidden = nativeAd.starRating == nil
                    
            (nativeAdView.storeView as? UILabel)?.text = nativeAd.store
            nativeAdView.storeView?.isHidden = nativeAd.store == nil
                    
            (nativeAdView.priceView as? UILabel)?.text = nativeAd.price
            nativeAdView.priceView?.isHidden = nativeAd.price == nil
                    
            (nativeAdView.advertiserView as? UILabel)?.text = nativeAd.advertiser
            nativeAdView.advertiserView?.isHidden = nativeAd.advertiser == nil
        self.height.constant = 315
        hideView.isHidden = false
    }
    
    func adLoader(_ adLoader: GADAdLoader, didFailToReceiveAdWithError error: Error) {
//        print("Native Ads StartViewController Error : \(error)")
    }
}

// MARK:- -----------------GADNativeAdDelegate Methodes-----------------
extension NativeAdsGoogle: GADNativeAdDelegate{
    func nativeAdDidRecordImpression(_ nativeAd: GADNativeAd) {
      // The native ad was shown.
    }

    func nativeAdDidRecordClick(_ nativeAd: GADNativeAd) {
      // The native ad was clicked on.
    }

    func nativeAdWillPresentScreen(_ nativeAd: GADNativeAd) {
      // The native ad will present a full screen view.
    }

    func nativeAdWillDismissScreen(_ nativeAd: GADNativeAd) {
      // The native ad will dismiss a full screen view.
    }

    func nativeAdDidDismissScreen(_ nativeAd: GADNativeAd) {
      // The native ad did dismiss a full screen view.
    }

    func nativeAdWillLeaveApplication(_ nativeAd: GADNativeAd) {
      // The native ad will cause the application to become inactive and
      // open a new application.
    }
}



