//
//  GoogleBannerAds.swift
//  Random Live Video Call
//
//  Created by MAC on 22/04/21.
//

import Foundation
import UIKit
import GoogleMobileAds

// MARK:- ------------------Google Banner Ads-----------------
class BannerAdsGoogle: NSObject {
    static let sharedInstance = BannerAdsGoogle()
    var bannerView: GADBannerView!
    var height: NSLayoutConstraint!
    var hideView: UIView!
    
    var vc: UIViewController!
    
    func createAndLoadBanner() -> GADBannerView{
        let bannerView = GADBannerView(adSize: kGADAdSizeBanner)
        bannerView.rootViewController = vc
        bannerView.delegate = self
        bannerView.adUnitID = bannerAdsUnitID
        bannerView.load(GADRequest())
        GADMobileAds.sharedInstance().requestConfiguration.testDeviceIdentifiers = testDeviceId
        return bannerView
    }
    
    func showFromViewController(vc: UIViewController, view: UIView, height:NSLayoutConstraint){
        self.height = height
        hideView = view
        hideView.isHidden = true
        self.vc = vc
        bannerView = createAndLoadBanner()
        view.addSubview(bannerView)
    }
}

// MARK:- ------------------GADBannerViewDelegate-----------------
extension BannerAdsGoogle: GADBannerViewDelegate{
    func bannerViewDidReceiveAd(_ bannerView: GADBannerView) {
        self.bannerView = bannerView
        self.height.constant = 50
        hideView.isHidden = false
    }

    func bannerView(_ bannerView: GADBannerView, didFailToReceiveAdWithError error: Error) {
        self.height.constant = 0
        hideView.isHidden = true
//      print("bannerView:didFailToReceiveAdWithError: \(error.localizedDescription)")
    }
}
