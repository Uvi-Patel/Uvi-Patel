//
//  OpenAds.swift
//  Random Live Video Call
//
//  Created by MAC on 28/04/21.
//

import Foundation
import UIKit
import GoogleMobileAds

// MARK:- ------------------Google OpenAdsGoogle Ads----------------
class OpenAdsGoogle: NSObject {
    static let sharedInstance = OpenAdsGoogle()
    var appOpenAd: GADAppOpenAd?
    var loadTime = Date()
    var window = appDelegate.window
    
    func requestAppOpenAd() {
        let request = GADRequest()
        GADAppOpenAd.load(withAdUnitID: appOpenAdsUnitId,
                          request: request,
                          orientation: UIInterfaceOrientation.portrait,
                          completionHandler: { (appOpenAdIn, _) in
                            self.appOpenAd = appOpenAdIn
                            self.appOpenAd?.fullScreenContentDelegate = self
                            self.loadTime = Date()
                          })
    }

    func tryToPresentAd() {
        if let gOpenAd = self.appOpenAd, let rwc = self.window?.rootViewController, wasLoadTimeLessThanNHoursAgo(thresholdN: 4) {
            gOpenAd.present(fromRootViewController: rwc)
        } else {
            self.requestAppOpenAd()
        }
    }

    func wasLoadTimeLessThanNHoursAgo(thresholdN: Int) -> Bool {
        let now = Date()
        let timeIntervalBetweenNowAndLoadTime = now.timeIntervalSince(self.loadTime)
        let secondsPerHour = 3600.0
        let intervalInHours = timeIntervalBetweenNowAndLoadTime / secondsPerHour
        return intervalInHours < Double(thresholdN)
    }
}

// MARK:- ------------------GADFullScreenContentDelegate----------------
extension OpenAdsGoogle: GADFullScreenContentDelegate{
    func ad(_ ad: GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        requestAppOpenAd()
    }

    func adDidDismissFullScreenContent(_ ad: GADFullScreenPresentingAd) {
        requestAppOpenAd()
    }

    func adDidPresentFullScreenContent(_ ad: GADFullScreenPresentingAd) {
        
    }
}
